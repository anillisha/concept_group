/*
 * User_I2cADchandler.h
 *
 *  Created on: Sep 22, 2024
 *      Author: anil
 */

#ifndef INC_USER_I2CADCHANDLER_H_
#define INC_USER_I2CADCHANDLER_H_



#endif /* INC_USER_I2CADCHANDLER_H_ */
