/*
 * User_I2cAdcHandler.c
 *
 *  Created on: Sep 22, 2024
 *      Author: anil
 */

#include "User_I2cAdcHandler.h"

